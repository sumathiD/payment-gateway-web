import React from 'react'

const PreferredPage = () => {
    return (
        <div>preferredPage</div>
    )
}

export default PreferredPage