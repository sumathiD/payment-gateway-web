import React from 'react'

const WalletsPage = () => {
    return (
        <div>walletsPage</div>
    )
}

export default WalletsPage