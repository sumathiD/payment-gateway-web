import React from 'react'

const UpiPage = () => {
  return (
    <div>upipages</div>
  )
}

export default UpiPage