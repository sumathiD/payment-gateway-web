import React from 'react'

const HeaderPage = () => {
    return (
        <div className='header' style={{
            background: "rgba(167, 29, 150, 0.136)",
            height: "39px"
        }}>
            <p style={{ marginLeft: "200px", paddingTop: "10px" }}> payment{">"}Credit & Debit card</p>
        </div>
    )
}

export default HeaderPage