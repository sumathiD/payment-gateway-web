import React from 'react'

const OtherPage = () => {
    return (
        <div>otherPage</div>
    )
}

export default OtherPage