import React from 'react'

const NetbankPage = () => {
  return (
    <div>Netbankpages</div>
  )
}

export default NetbankPage